Mercury World original public design bundle

Source: Cafe24 DATA backup provided by site owner.

Included:
- Public-facing PHP templates/pages
- CSS, JS, image assets
- Upload assets for public content/attachments

Excluded intentionally:
- admin/
- conf/
- lib/
- cache/
- zwebmy/ phpMyAdmin
- database SQL backup
- hidden server files

Do not commit full Cafe24 backup, DB dump, conf/, zwebmy/, admin/, or cache/ to public GitHub.
Use this bundle as source material for rebuilding the public frontend/design in Next.js.
