<?
$pageNum="4";
$sub = "1";
?>
<? include "../inc/header.php"; ?>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="213" valign="top">
	<!--left -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td><img src="../img/community/left_top.gif" /></td>
	  </tr>
	  <tr>
		<td background="../img/news/left_bg.gif" style="padding-left:18">
		<!--<script>var ff4 = f_emb(140, 150, "/flash/left_community.swf?pageNum=<?=$sub?>","transparent");documentwrite(ff4);</script>-->
		<ul class="side_nav"><?	print_side_nav(1400); //@@@ /inc/header.php에 정의됨.?></ul>
		</td>
	  </tr>
	  <tr>
		<td><img src="../img/community/left_bottom.gif" /></td>
	  </tr>
	</table>
	<!--/left -->	</td>
	<td width="727" valign="top">
	<!--con -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2"><img src="../img/community/img.gif" /></td>
      </tr>
      <tr>
        <td width="14%" valign="bottom"><img src="../img/community/title_1.gif" /></td>
        <td width="86%" align="right" valign="bottom" class="here" style="padding-bottom:3">HOME &gt; 수은상담소 &gt; 묻고답하기 </td>
      </tr>
      <tr>
        <td height="3" background="../img/community/title_line_1.gif"></td>
        <td height="3" background="../img/community/title_line_2.gif"></td>
      </tr>
      <tr>
        <td height="27" colspan="2"></td>
        </tr>
    </table>
	<table width="100%" height="20" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td valign="top" style="padding-bottom:5"><img src="../img/community/text_1.gif" /></td>
	  </tr>
	</table>

	<script>
 function resizeFrame(iframeObj){
  var innerBody = iframeObj.contentWindow.document.body;
  oldEvent = innerBody.onclick;
  innerBody.onclick = function(){ resizeFrame(iframeObj, 1);oldEvent; };
  var innerHeight = innerBody.scrollHeight + (innerBody.offsetHeight - innerBody.clientHeight);
  iframeObj.style.height = innerHeight;
  var innerWidth = innerBody.scrollWidth + (innerBody.offsetWidth - innerBody.clientWidth);
  iframeObj.style.width = innerWidth;     
  if( !arguments[1] )        /* 특정 이벤트로 인한 호출시 스크롤을 그냥 둔다. */
    this.scrollTo(1,1);
 }
</script>
<!-- <iframe src="/modules/board/bd_list.html?id=freeboard" onload="resizeFrame(this)" frameborder=0 width=100% scrolling="no"></iframe> -->
<iframe src="/modules/board/bd_list.html?id=anerhekqgkrl1" onload="resizeFrame(this)" frameborder=0 width=100% scrolling="no"></iframe>
	<!--/con --></td>
  </tr>
</table><table width="100" height="30" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<? include "../inc/footer.php"; ?>