<?
$pageNum="4";
$sub = "2";
?>
<? include "../inc/header.php"; ?>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="213" valign="top">
	<!--left -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td><img src="../img/community/left_top.gif" /></td>
	  </tr>
	  <tr>
		<td background="../img/news/left_bg.gif" style="padding-left:18">
		<!--<script>var ff4 = f_emb(140, 150, "/flash/left_community.swf?pageNum=<?=$sub?>","transparent");documentwrite(ff4);</script>-->
		<ul class="side_nav"><?	print_side_nav(1400); //@@@ /inc/header.php에 정의됨.?></ul>
		</td>
	  </tr>

	  <tr>
		<td><img src="../img/community/left_bottom.gif" /></td>
	  </tr>
	</table>
	<!--/left -->	</td>
	<td width="727" align="center" valign="top">
	<!--con -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2"><img src="../img/community/img.gif" /></td>
      </tr>
      <tr>
        <td width="11%" valign="bottom"><img src="../img/community/title_2.gif" /></td>
        <td width="89%" align="right" valign="bottom" class="here" style="padding-bottom:3">HOME &gt; 수은상담소 &gt; 분석의뢰 </td>
      </tr>
      <tr>
        <td height="3" background="../img/community/title_line_1.gif"></td>
        <td height="3" background="../img/community/title_line_2.gif"></td>
      </tr>
      <tr>
        <td height="27" colspan="2"></td>
        </tr>
    </table>
	<table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="30" align="center"><img src="../img/community/request_1.gif" /></td>
      </tr>
	  <tr>
        <td height="27"></td>
      </tr>
    </table>
	<table width="697" border="0" cellpadding="0" cellspacing="0"  style="border:solid 5 #eeeeee;">
      <tr>
        <td>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr>
			<td style="padding: 10 10 10 10"><img src="../img/community/request_2.gif" /></td>
		    </tr>
		</table>

		</td>
      </tr>
    </table>
	<!--/con --></td>
  </tr>
</table><table width="100" height="30" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<? include "../inc/footer.php"; ?>