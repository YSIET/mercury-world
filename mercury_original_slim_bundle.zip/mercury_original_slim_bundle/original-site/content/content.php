<?
$mod_file_path = __FILE__;
include_once "../lib/include.inc2.html";

//2023.12.22 박종천
@$db2 = new DB($ini["db"]["host"], $ini["db"]["user"], $ini["db"]["pass"], $ini["db"]["db"]);


$pageNum="5";
$sub = "1";
include "../inc/header.php";
?>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) {
	//v2.0
	window.open(theURL,winName,features);
}
//-->
</script>
<script>
function v_h(num){
	if (document.getElementById("ck_"+num).checked == true)	{
		document.getElementById("cont2_"+num).style.display = "block";
		document.getElementById("cont3_"+num).style.display = "block";
	}
	else{
		document.getElementById("cont2_"+num).style.display = "none";
		document.getElementById("cont3_"+num).style.display = "none";
	}
}
function t_s(){
	var tot = 0;
	var w = document.frm1.w.value
	for (var idx=0; idx<document.frm1.length; idx++)
	{
		var obj = document.frm1[idx];
		switch(obj.type)
		{
			case "checkbox":
			if (obj.checked) {
				tot = tot + parseFloat(document.getElementById("in_"+obj.value).value) * parseFloat(document.getElementById("or_"+obj.value).value);
			}
		}
	}

	MM_openBrWindow('popup.php?w='+w+'&tot='+tot,'as','width=600,height=300')
}
</script>
<table border="0" cellspacing="0" cellpadding="0">
<tr>
	<td width="213" valign="top">
		<!--left -->
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td><img src="../img/content/left_top.gif" /></td>
		</tr>
	  <tr>
		<td background="../img/news/left_bg.gif" style="padding-left:18">
		<!--<script>var ff4 = f_emb(140, 150, "/flash/left_content.swf?pageNum=<?=$sub?>","transparent");documentwrite(ff4);</script>-->
		<ul class="side_nav"><?	print_side_nav(1500); //@@@ /inc/header.php에 정의됨.?></ul>
		</td>
	  </tr>
		<tr>
			<td><img src="../img/content/left_bottom.gif" /></td>
		</tr>
		</table>
		<!--/left -->	
	</td>
	<td width="727" align="center" valign="top">
		<!--con -->
		<form name=frm1>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td colspan="2"><img src="../img/content/img.gif" /></td>
		</tr>
		<tr>
			<td width="28%" valign="bottom"><img src="../img/content/title_1.gif" /></td>
			<td width="72%" align="right" valign="bottom" class="here" style="padding-bottom:3">HOME &gt; 식품 속 수은 &gt; 수은 섭취 자가 테스트</td>
		</tr>
		<tr>
			<td height="3" background="../img/content/title_line_1.gif"></td>
			<td height="3" background="../img/content/title_line_2.gif"></td>
		</tr>
		<tr>
			<td height="27" colspan="2"></td>
		</tr>
		</table>

		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td class="c2 bold"><img src="../img/content/content_1.gif" /></td>
			<td width="30%" valign="bottom" class="c2 bold">
				<table border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td><strong>몸무게</strong>&nbsp;</td>
					<td>
						<input name="w" type="text" size="15" style=" background-color:#ffffff; border:solid 2px #FF6600"  />
						kg
					</td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td width="70%" class="c2 bold" style="padding-bottom:3px"><img src="../img/content/content_1_1.gif" /></td>
			<td valign="bottom" class="c2 bold"><img src="../img/content/mer_ok.gif" onclick="t_s()" style="cursor:hand" /> <img src="../img/content/mer_cancel.gif" style="cursor:hand" onclick="javascript:document.frm1.reset()"/></td>
		</tr>
		</table>

		<table width="700" border="1" bordercolor="#CCCCCC" align="center" cellpadding="10" cellspacing="0" frame="hsides" style="border-collapse:collapse; ">
		<tr>
			<td width="50" align="center" bgcolor="#CFEAEF"><strong>분류</strong></td>
			<td width="350" align="center" bgcolor="#CFEAEF"><strong>내용물</strong></td>
			<td width="150" align="center" bgcolor="#CFEAEF"><strong>식사량</strong></td>
			<td width="150" align="center" bgcolor="#CFEAEF"><span style="font-weight: bold">비고</span></td>
		</tr>
<?
		$db->query("select idx, name from cat1 where idx > 14 ");
		for($i=0; $row_ca = $db->fetch(); $i++){
			if($i>100){
				break;
			}

			$j = 0;

			$str = $row_ca[name];
 /*		if ($i == 1){
			$str = "잡곡";
		}else if($i == 2){
			$str = "과일";
		}else if($i == 3){
			$str = "나물";
		}else if($i == 4){
			$str = "조미료";
		}else if($i == 5){
			$str = "면";
		}else if($i == 6){
			$str = "부식";
		}else if($i == 7){
			$str = "스낵";
		}else if($i == 8){
			$str = "음료";
		}else if($i == 9){
			$str = "해산물";
		}else if($i == 10){
			$str = "김치";
		}else if($i == 11){
			$str = "고기";
		}else if($i == 12){
			$str = "야채";
		}
			*/
			$cont_1 = "";
			$cont_2 = "";
			$cont_3 = "";
			$j = 0;
			$db2->query("select * from frame_board_mercury_eat where bd_order= ". $row_ca['idx']);
			for($n=0; $row = $db2->fetch(); $n++){
				$j ++;
				if ($j % 2 ==1) $cont_1 .= "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr>";
				$cont_1 .=  " <td width=50%><input type=\"checkbox\" name=\"ck_".$row[bd_no]."\" id=\"ck_".$row[bd_no]."\" value=\"".$row['bd_no']."\" onclick=\"v_h(".$row[bd_no].")\" /> ".$row['userName']."</td> ";
				if ($j % 2 ==0) $cont_1 .= "</tr></table>";
				
				$cont_2 .= " <div id='cont2_".$row[bd_no]."' style=\"display:none\">".$row['userName']." <input name=\"in_".$row[bd_no]."\" type=\"text\" id=\"in_".$row[bd_no]."\" class=\"input_content\" size=\"3\" value='0' /> g<input type=hidden id=\"or_".$row[bd_no]."\" value=\"".$row['userPass']."\"><br></div>";
				$cont_3 .= " <div id='cont3_".$row[bd_no]."' style=\"display:none\">".$row[bd_title]."<br></div>";
				if($n>100){
					break;
				}

			}

			if ($j % 2 !=0) $cont_1 .= "<td width=50%>&nbsp;</td></tr></table>";


			if ($cont_1 == ""){
			}
			else{
		?>
		<tr>
			<td align="center" bgcolor="#F5FBFE"><strong><?=$str?></strong></td>
			<td align="center"><?=$cont_1?></td>
			<td align="right" bgcolor="#F1FAFA"><?=$cont_2?></td>
			<td align="right"><?=$cont_3?></td>
		</tr>
<?
			}
		}
?>

		<!--
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>
  잡곡
    </strong>
    <td align="center">

      <input type="checkbox" name="checkbox" id="checkbox31" />
      백미
  <input type="checkbox" name="checkbox2" id="checkbox2" />
      밀가루
  <input type="checkbox" name="checkbox3" id="checkbox3" />
      밀가루
  <input type="checkbox" name="checkbox4" id="checkbox4" />
      밀가루
  <input type="checkbox" name="checkbox5" id="checkbox5" />
      밀가루<br />
  <input type="checkbox" name="checkbox2" id="checkbox" />
      백미
  <input type="checkbox" name="checkbox2" id="checkbox2" />
      밀가루
  <input type="checkbox" name="checkbox3" id="checkbox3" />
      밀가루
  <input type="checkbox" name="checkbox4" id="checkbox4" />
      밀가루
  <input type="checkbox" name="checkbox5" id="checkbox5" />
      밀가루<br />
  <input type="checkbox" name="checkbox2" id="checkbox" />
      백미
  <input type="checkbox" name="checkbox2" id="checkbox2" />
      밀가루
  <input type="checkbox" name="checkbox3" id="checkbox3" />
      밀가루
  <input type="checkbox" name="checkbox4" id="checkbox4" />
      밀가루
  <input type="checkbox" name="checkbox5" id="checkbox5" />
      밀가루<br />
  <input type="checkbox" name="checkbox10" id="checkbox26" />
      백미
  <input type="checkbox" name="checkbox10" id="checkbox27" />
      밀가루
  <input type="checkbox" name="checkbox10" id="checkbox28" />
      밀가루
  <input type="checkbox" name="checkbox10" id="checkbox29" />
      밀가루
  <input type="checkbox" name="checkbox10" id="checkbox30" />
    밀가루<br />  </td>

  <td align="right" bgcolor="#F1FAFA">백미
    <input name="textfield" type="text" id="textfield" class="input_content" size="3" /> g  </td>

  <td align="right">백미1공기 : 10g</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>과일</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox6" id="checkbox6" />
      사과
      <input type="checkbox" name="checkbox6" id="checkbox7" />
      배
      <input type="checkbox" name="checkbox6" id="checkbox8" />
      수박<br />    </td>
    <td align="right" bgcolor="#F1FAFA">수박
      <input name="textfield2" type="text" id="textfield2" class="input_content" size="3" /> g </td>
    <td align="right">수박1통 : 100g</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>나물</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox7" id="checkbox11" />
      치나물
      <input type="checkbox" name="checkbox7" id="checkbox12" />
      드룹
      <input type="checkbox" name="checkbox7" id="checkbox13" />
      고사리<br />    </td>
    <td align="right" bgcolor="#F1FAFA">고사리
      <input name="textfield3" type="text" id="textfield3" class="input_content" size="3" /> g<br />
    드룹
    <input name="textfield14" type="text" id="textfield14" class="input_content" size="3" /> g</td>
    <td align="right">고사리 1그릇 : 5g<br />
      두릅 1그룻 : 3g</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>조미료</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox8" id="checkbox16" />
      미원
      <input type="checkbox" name="checkbox8" id="checkbox17" />
      다시다
      <input type="checkbox" name="checkbox8" id="checkbox18" />
      후추<br />    </td>
    <td align="right" bgcolor="#F1FAFA">다시다
      <input name="textfield4" type="text" id="textfield4" class="input_content" size="3" /> g<br />
      후추
        <input name="textfield5" type="text" id="textfield5" class="input_content" size="3" /> g </td>
    <td align="right">다시다 1스푼 : 1g<br />
      후추 1스푼 : 1g</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>면</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox9" id="checkbox21" />
      국수
      <input type="checkbox" name="checkbox9" id="checkbox22" />
      라면
      <input type="checkbox" name="checkbox9" id="checkbox23" />
      메밀<br />    </td>
    <td align="right" bgcolor="#F1FAFA">라면
      <input name="textfield6" type="text" id="textfield6" class="input_content" size="3" /> g </td>
    <td align="right">라면 1개 : 3g</td>
  </tr>
    <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>부식</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox6" id="checkbox6" />
      백미
      <input type="checkbox" name="checkbox6" id="checkbox7" />
      밀가루
      <input type="checkbox" name="checkbox6" id="checkbox8" />
      밀가루
      <input type="checkbox" name="checkbox6" id="checkbox9" />
      밀가루
      <input type="checkbox" name="checkbox6" id="checkbox10" />
      밀가루<br />    </td>
    <td align="right" bgcolor="#F1FAFA">백미
      <input name="textfield7" type="text" id="textfield7" class="input_content" size="3" /> g </td>
    <td align="right">&nbsp;</td>
    </tr>
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>스낵</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox7" id="checkbox11" />
      백미
      <input type="checkbox" name="checkbox7" id="checkbox12" />
      밀가루
      <input type="checkbox" name="checkbox7" id="checkbox13" />
      밀가루
      <input type="checkbox" name="checkbox7" id="checkbox14" />
      밀가루
      <input type="checkbox" name="checkbox7" id="checkbox15" />
    밀가루<br />    </td>
    <td align="right" bgcolor="#F1FAFA">백미
      <input name="textfield8" type="text" id="textfield8" class="input_content" size="3" /> g </td>
    <td align="right">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>음료</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox8" id="checkbox16" />
      백미
      <input type="checkbox" name="checkbox8" id="checkbox17" />
      밀가루
      <input type="checkbox" name="checkbox8" id="checkbox18" />
      밀가루
      <input type="checkbox" name="checkbox8" id="checkbox19" />
      밀가루
      <input type="checkbox" name="checkbox8" id="checkbox20" />
    밀가루<br />    </td>
    <td align="right" bgcolor="#F1FAFA">백미
      <input name="textfield9" type="text" id="textfield9" class="input_content" size="3" /> g </td>
    <td align="right">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>해산물</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox9" id="checkbox21" />
      백미
      <input type="checkbox" name="checkbox9" id="checkbox22" />
      밀가루
      <input type="checkbox" name="checkbox9" id="checkbox23" />
      밀가루
      <input type="checkbox" name="checkbox9" id="checkbox24" />
      밀가루
      <input type="checkbox" name="checkbox9" id="checkbox25" />
    밀가루<br />    </td>
    <td align="right" bgcolor="#F1FAFA">백미
      <input name="textfield10" type="text" id="textfield10" class="input_content" size="3" /> g </td>
    <td align="right">&nbsp;</td>
  </tr>
    <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>김치</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox6" id="checkbox6" />
      백미
      <input type="checkbox" name="checkbox6" id="checkbox7" />
      밀가루
      <input type="checkbox" name="checkbox6" id="checkbox8" />
      밀가루
      <input type="checkbox" name="checkbox6" id="checkbox9" />
      밀가루
      <input type="checkbox" name="checkbox6" id="checkbox10" />
      밀가루<br />    </td>
    <td align="right" bgcolor="#F1FAFA">백미
      <input name="textfield11" type="text" id="textfield11" class="input_content" size="3" /> g </td>
    <td align="right">&nbsp;</td>
    </tr>
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>고기</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox7" id="checkbox11" />
      백미
      <input type="checkbox" name="checkbox7" id="checkbox12" />
      밀가루
      <input type="checkbox" name="checkbox7" id="checkbox13" />
      밀가루
      <input type="checkbox" name="checkbox7" id="checkbox14" />
      밀가루
      <input type="checkbox" name="checkbox7" id="checkbox15" />
    밀가루<br />    </td>
    <td align="right" bgcolor="#F1FAFA">백미
      <input name="textfield12" type="text" id="textfield12" class="input_content" size="3" /> g </td>
    <td align="right">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#F5FBFE"><strong>야채</strong></td>
    <td align="center">
      <input type="checkbox" name="checkbox8" id="checkbox16" />
      백미
      <input type="checkbox" name="checkbox8" id="checkbox17" />
      밀가루
      <input type="checkbox" name="checkbox8" id="checkbox18" />
      밀가루
      <input type="checkbox" name="checkbox8" id="checkbox19" />
      밀가루
      <input type="checkbox" name="checkbox8" id="checkbox20" />
    밀가루<br />    </td>
    <td align="right" bgcolor="#F1FAFA">백미
      <input name="textfield13" type="text" id="textfield13" class="input_content" size="3" /> g </td>
    <td align="right">&nbsp;</td>
  </tr>  -->
		</table>
		</form>
		<table width="697" border="0" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td align="center"><a href="http://fsi.seoul.go.kr/" target="_blank"><img src="../img/content/content_3.gif" border="0" /></a></td>
		</tr>
		</table>
		<!--/con -->
	</td>
</tr>
</table>
<table width="100" height="30" border="0" cellpadding="0" cellspacing="0">
<tr>
	<td>&nbsp;</td>
</tr>
</table>
<? include "../inc/footer.php"; ?>
