<?session_start() ?>
<?
	$tot_al = $tot /1000;
?>
<?
	
        $connect = mysql_connect("localhost","mercury24","m@^20231219");
        mysql_select_db("mercury24");
		//mysql_query("SET NAMES euckr"); //2023.12.18 박종천
		$nowDate = date("Y-m-d",time());
		$s_id = session_id();
		$sql = "select count(idx) cnt from f_statist where reg_dt ='$nowDate' and etc1 = '$s_id'";
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		$cnt = $row[cnt];
		if ($cnt == 0){
		$sql = "insert into f_statist (reg_dt, etc1) values ('$nowDate', '$s_id')";
			mysql_query($sql);
		}

		$m = (int)((5*$w)/7);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<title>무제 문서</title></head>

<body>
<table width="600" height="300" border="0" cellspacing="0" cellpadding="0" style="border:10px #5fb3b3 solid" background="../img/content/content_4.gif">
  <tr>
    <td width="188">&nbsp;</td>
    <td width="330" align="center" valign="top" style="padding-top:72px">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td align="center"><strong>나의 수은 섭취량</strong></td>
        </tr>
        <tr>
          <td height="8"></td>
        </tr>
      </table>
        <table width="131" height="45" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center">
			<?if ($tot_al <= 19){?>
            <img src="../img/content/green.gif">
			<?}else if($tot_al > 19 && $tot_al <=$m){?>
            <img src="../img/content/yellow.gif">
			<?}else{?>
            <img src="../img/content/red.gif">
			<?}?>
</td>
          </tr>
        </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="8"></td>
          </tr>
          <tr>
			<?if ($tot_al <= 19){?>
            <td align="center"><strong>일일 평균 수은 섭취량 이하이시군요.<br />
              오늘은 조절을 잘하셨어요.</strong></td>
			<?}else if($tot_al > 19 && $tot_al <=$m){?>
            <td align="center"><strong>일일 평균 수은 섭취량을 초과하셨어요.<br />
              오늘은 조심하실 필요가 있습니다.</strong></td>
			<?}else{?>
            <td align="center"><strong>일일 수은 섭취 권고치를 초과하셨어요.<br />
              식습관을 조절하셔서 수은 섭취량을 줄이셔야 합니다.</strong></td>
			<?}?>
          </tr>
			<tr>
				<td align=center class="c2 f11">(단, 이 값은 식품별 수은 농도 측정 결과를<br /> 바탕으로
			    한 추정치로 절대값은 아닙니다)</td>
		</tr>
      </table></td>
    <td width="62" align="center">&nbsp;</td>
  </tr>
<tr></tr>
</table>
</body>
</html>
