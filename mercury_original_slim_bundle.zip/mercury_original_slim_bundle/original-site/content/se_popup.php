<link href="../css/style.css" rel="stylesheet" type="text/css" /><br />
<div align="center">
  <table width="1" border="1" cellpadding="0" cellspacing="0" bordercolor="#C0C0C0" style="border-collapse:collapse">
    <tr>
      <td><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="700" height="600">
        <param name="movie" value="../flash/seoul_popup.swf" />
        <param name="quality" value="high" />
        <embed src="../flash/seoul_popup.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="700" height="600"></embed>
      </object></td>
    </tr>
  </table>
  </div>
