<?
        $connect = mysql_connect("localhost","mercury24","m@^20231219");
        mysql_select_db("mercury24");
		//mysql_query("SET NAMES euckr"); //2023.12.18 박종천
?>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<script>
	function v_h(num){
		if (document.getElementById("ck_"+num).checked == true)	{
			document.getElementById("cont2_"+num).style.display = "block";
			document.getElementById("cont3_"+num).style.display = "block";
		}else{
			document.getElementById("cont2_"+num).style.display = "none";
			document.getElementById("cont3_"+num).style.display = "none";
		}
	}
	function t_s(){
		var tot = 0;
		var w = document.frm1.w.value
		for (var idx=0; idx<document.frm1.length; idx++)  
		{
			var obj = document.frm1[idx];
			switch(obj.type)
			{
			  case "checkbox":
				  if (obj.checked) {
					tot = tot + parseFloat(document.getElementById("in_"+obj.value).value) * parseFloat(document.getElementById("or_"+obj.value).value);
				  }
			  } 
		}
		
		MM_openBrWindow('popup.php?w='+w+'&tot='+tot,'as','width=600,height=300')
	}
</script>
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
    <td height="40" align="center"></td>
  </tr>
  <tr>
    <td align="center"><a href="se_popup.php"><img src="../img/content/logo.gif" border="0" /></a></td>
  </tr>
  <tr>
    <td height="28" align="center"></td>
  </tr>
  <tr>
    <td align="center">
    <a href="se_popup_1.php" style="cursor:hand"><img src="../img/content/tab_1.gif" border="0" /></a>&nbsp;
    <a href="se_popup_2.php" style="cursor:hand"><img src="../img/content/tab_2.gif" border="0" /></a>&nbsp;
    <a href="se_popup_3.php" style="cursor:hand"><img src="../img/content/tab_3_ov.gif" border="0" /></a>&nbsp;
    <a href="se_popup_4.php" style="cursor:hand"><img src="../img/content/tab_4.gif" border="0" /></a></td>
  </tr>
  <tr>
    <td height="30"></td>
  </tr>
  <tr>
    <td align="right"><form name="frm1" id="frm1">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td class="c2 bold"><img src="../img/content/content_1.gif" /></td>
        <td width="27%" valign="bottom" class="c2 bold"><table border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td><strong>몸무게</strong>&nbsp;</td>
            <td><input name="w" type="text" size="15" style=" background-color:#ffffff; border:solid 2px #FF6600"  />
              kg</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="73%" class="c2 bold" style="padding-bottom:3px"><img src="../img/content/content_1_1.gif" /></td>
        <td valign="bottom" class="c2 bold"><img src="../img/content/mer_ok.gif" onclick="t_s()" style="cursor:hand" /> <img src="../img/content/mer_cancel.gif" style="cursor:hand" onclick="javascript:document.frm1.reset()"/></td>
        </tr>
      </table>
      
        <table width="100%" border="1" bordercolor="#CCCCCC" cellpadding="3" cellspacing="0" frame="hsides" style="border-collapse:collapse; ">
          <tr>
            <td width="40" align="center" bgcolor="#CFEAEF"><strong>분류</strong></td>
            <td width="380" align="center" bgcolor="#CFEAEF"><strong>내용물</strong></td>
            <td width="140" align="center" bgcolor="#CFEAEF"><strong>식사량</strong></td>
            <td width="140" align="center" bgcolor="#CFEAEF"><span style="font-weight: bold">비고</span></td>
          </tr>
          <?
	$sql_ca = "select  * from cat1 where idx > 14 ";
	$result_ca = mysql_query($sql_ca);
	while($row_ca = mysql_fetch_array($result_ca)){
//for ($i = 1 ; $i < 13 ; $i++){
$sql = "select * from frame_board_mercury_eat where bd_order= $row_ca[idx] ";
$result = mysql_query($sql);
//		$row_cnt = mysql_num_rows($result);

$j = 0;
$str = $row_ca[name];
/*
if ($i == 1){
$str = "잡곡";
}else if($i == 2){
$str = "과일";
}else if($i == 3){
$str = "나물";		
}else if($i == 4){
$str = "조미료";
}else if($i == 5){
$str = "면";
}else if($i == 6){
$str = "부식";
}else if($i == 7){
$str = "스낵";
}else if($i == 8){
$str = "음료";
}else if($i == 9){
$str = "해산물";
}else if($i == 10){
$str = "김치";
}else if($i == 11){
$str = "고기";
}else if($i == 12){
$str = "야채";
}
*/
$cont_1 = "";
$cont_2 = "";
$cont_3 = "";
$j = 0;
while($row = mysql_fetch_array($result)){
$j ++;
if ($j % 3 ==1) $cont_1 .= "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr>";
$cont_1 .=  " <td width=33%><input type=\"checkbox\" name=\"ck_".$row[bd_no]."\" id=\"ck_".$row[bd_no]."\" value=\"".$row['bd_no']."\" onclick=\"v_h(".$row[bd_no].")\" /> ".$row['userName']."</td> ";
if ($j % 3 ==0) $cont_1 .= "</tr></table>";
$cont_2 .= " <div id='cont2_".$row[bd_no]."' style=\"display:none\">".$row['userName']." <input name=\"in_".$row[bd_no]."\" type=\"text\" id=\"in_".$row[bd_no]."\" class=\"input_content\" size=\"3\" value='0' /> g<input type=hidden id=\"or_".$row[bd_no]."\" value=\"".$row['userPass']."\"><br></div>";
$cont_3 .= " <div id='cont3_".$row[bd_no]."' style=\"display:none\">".$row[bd_title]."<br></div>";
}
if ($j % 3 !=0) $cont_1 .= "<td width=34%>&nbsp;</td></tr></table>";



if ($cont_1 == ""){
}else{
?>
          <tr>
            <td align="center" bgcolor="#F5FBFE"><strong>
              <?=$str?>
            </strong></td>
            <td><?=$cont_1?></td>
            <td align="right" bgcolor="#F1FAFA"><?=$cont_2?></td>
            <td align="right"><?=$cont_3?></td>
          </tr>
          <?
}

}


		$nowDate = date("Y-m-d",time());
		$sql_to = "select count(*) cnt from f_statist where reg_dt = '$nowDate'";
		$result_to = mysql_query($sql_to);
		$row_to = mysql_fetch_array($result_to);
		$to_cnt = $row_to[cnt];
		$sql = "select count(*) cnt from f_statist ";
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		$cnt = $row[cnt];
mysql_close();
?>
        </table>
      </form>
      <table width="700" align="center" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="298" align="left"><img src="../img/common/icon03.gif" width="9" height="9" /> 금일 방문자수 : <span class="c2 bold"><?=$to_cnt?></span> 명<br />

      <img src="../img/common/icon03.gif" width="9" height="9" /> 전체 방문자수 :  <span class="c2 bold"><?=$cnt?></span> 명</td>
    <td width="402" align="right"><a href="http://www.mercury.or.kr/" target="_blank"><img src="../img/content/mercury.gif" border="0" /></a></td>
  </tr>
</table>
    </td>
  </tr>
</table>
<br />
<br />