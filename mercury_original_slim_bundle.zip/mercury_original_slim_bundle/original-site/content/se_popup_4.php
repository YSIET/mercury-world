<link href="../css/style.css" rel="stylesheet" type="text/css" />
<table width="700" align="center" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td height="40" align="center"></td>
  </tr>
  <tr>
    <td align="center"><a href="se_popup.php"><img src="../img/content/logo.gif" border="0" /></a></td>
  </tr>
  <tr>
    <td height="28" align="center"></td>
  </tr>
  <tr>
    <td align="center">
    <a href="se_popup_1.php" style="cursor:hand"><img src="../img/content/tab_1.gif" border="0" /></a>&nbsp;
    <a href="se_popup_2.php" style="cursor:hand"><img src="../img/content/tab_2.gif" border="0" /></a>&nbsp;
    <a href="se_popup_3.php" style="cursor:hand"><img src="../img/content/tab_3.gif" border="0" /></a>&nbsp;
    <a href="se_popup_4.php" style="cursor:hand"><img src="../img/content/tab_4_ov.gif" border="0" /></a></td>
  </tr>
  <tr>
    <td height="30"></td>
  </tr>
  <tr>
    <td><img src="../img/content/sinho.gif" /></td>
  </tr>
  <tr>
    <td height="30"></td>
  </tr>
  <tr>
    <td><table width="700" align="center" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center"><a href="http://www.mercury.or.kr/" target="_blank"><img src="../img/content/content_6.gif" border="0" /></a></td>
  </tr>
</table></td>
  </tr>
</table>
<br />
<br />