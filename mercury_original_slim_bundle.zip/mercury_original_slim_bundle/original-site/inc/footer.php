<style type="text/css">
<!--
.style6 {
	font-size: 11px;
	color: #007bd1;
}
-->
</style>

<table width="914" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2"><img src="../img/common/copyright_1.gif"></td>
  </tr>
  <tr>
    <td width="809" height="90" valign="top"><img src="../img/common/copyright_2.gif?t=20200103"></td>
    <td width="150" valign="top">
	  <table width="128" height="37" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td align="center" background="../img/common/footer_today.gif" style="background-repeat:no-repeat">
	<?php 

$mod_file_path = __FILE__;
@ include_once "../lib/include.inc2.html";
		statisticsShow('statistics.htm'); ?>
	            </td>
			</tr>
		</table>
	
	</td>
  </tr>
</table>
</center>
<?
	//2015.07.10 -- 2018.06.28
	if($_COOKIE['pop_2'] != "ok1"){
?>
	<style type="text/css">
	/*팝업창 관련*/
		div.popup {position:absolute; z-index:8; background:#333333; overflow:hidden; padding:1px;}
		div.popup p {margin:0; padding:0; }
		div.popup_content {display:none; }
		div.popup_content map area {cursor:pointer; }

		div.popup_bt { background:#333333; color:#ffffff; height:30px;  line-height:27px; position:relative; padding-left:5px; }
		div.popup_bt strong {cursor:pointer; font-size:24px; margin-left:50px; position:absolute; bottom:2px; right:5px; }
		div.popup_bt * {vertical-align:middle; }
		div.popup_bt input {display:none; }
	</style>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
	<script language="javascript" src="../js/popup_new.js"></script>
	<div class="popup_content" id="content_2">
		<img src="/img/qha_popup_20180628.gif" width="300" height="276" border="0" usemap="#qha_popup_20180628">
		<map name="qha_popup_20180628">
			<area shape="rect" coords="61,224,287,267" href="http://www.s2b.kr/S2BNCustomer/S2B/index.jsp" target="_blank" alt="수은응급처리키트">
		</map>
	</div>
	<script type="text/javascript">
		//openPopup(2, 300, 276, 75, 250, 1);
	</script>

<?
	}//_COOKIE
?>
</body>
</html>

