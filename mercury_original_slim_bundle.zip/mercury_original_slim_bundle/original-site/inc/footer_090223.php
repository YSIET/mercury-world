<table width="914" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2"><img src="../img/common/copyright_1.gif"></td>
  </tr>
  <tr>
    <td width="809" height="90" valign="top"><img src="../img/common/copyright_2.gif"></td>
    <td width="131" align="right" valign="top"><!-- <table border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><a href="http://www.me.go.kr/" target="_blank"><img src="../img/common/1.jpg" border="0" /></a></td>
        </tr>
    </table>       -->
    <!--script>var ff4 = f_emb(470, 40, "../flash/sitelink.swf","transparent");documentwrite(ff4);</script--></td>
  </tr>
</table>
</center>
</body>
</html>