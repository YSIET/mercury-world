<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
<title>수은세상</title>
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="../js/f_fscript.js"></script>
<SCRIPT language="javascript" src="../js/etc.js"></SCRIPT>
<!--2016.07.14-->
<meta name="naver-site-verification" content="49469930b8af79467aea1fa71a1e2258732c31ef"/>
</head>
<body>
<center>
<script>
//quick
self.onError=null;
currentX = currentY = 0; 
whichIt = null; 
lastScrollX = 0; lastScrollY = 0;
NS = (document.layers) ? 1 : 0;
IE = (document.all) ? 1: 0;
<!-- STALKER CODE -->
var limitY;
function heartBeat() {
if(IE) { 
diffY = document.body.scrollTop; 
diffX = 0; 
}
if(NS) { diffY = self.pageYOffset; diffX = self.pageXOffset; }
if(diffY >limitY) diffY = limitY;
if(diffY != lastScrollY) {
percent = .1 * (diffY - lastScrollY);
if(percent > 0) percent = Math.ceil(percent);
else percent = Math.floor(percent);
if(IE) document.all.floater.style.pixelTop += percent;
if(NS) document.floater.top += percent; 
lastScrollY = lastScrollY + percent;
}
if(diffX != lastScrollX) {
percent = .1 * (diffX - lastScrollX);
if(percent > 0) percent = Math.ceil(percent);
else percent = Math.floor(percent);
if(IE) document.all.floater.style.pixelLeft += percent;
if(NS) document.floater.top += percent;
lastScrollY = lastScrollY + percent;
} 
} 
if(NS || IE) action = window.setInterval("heartBeat()",1);
window.onload = function() {
    limitY = document.body.scrollHeight - parseInt(document.all.floater.style.height) - parseInt(document.all.floater.style.top);
}
</script>
<div align="center" id="floater" style="position:absolute; left:50%; margin-left:490px;top:150px;	width:53px;height:10px;z-index:2">
	<table border="0" cellpadding="0" cellspacing="0" background="/img/common/quick_bg.gif">
	  <tr>
		<td align="right"><img src="/img/common/quick_top.gif" /></td>
	  </tr>
	  <tr>
		<td height="5"></td>
	  </tr>
	  <tr>
		<td align="right"><a href="/site/greeting.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image11','','/img/common/quick_1_ov.gif',1)"><img src="/img/common/quick_1.gif" name="Image11" border="0"></a></td>
	  </tr>
	  <tr>
		<td height="10"></td>
	  </tr>
	  <tr>
		<td align="right"><a href="/community/freeboard.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image12','','/img/common/quick_2_ov.gif',1)"><img src="/img/common/quick_2.gif" name="Image12" border="0"></a></td>
	  </tr>
	  <tr>
		<td height="10"></td>
	  </tr>
	  <tr>
		<td align="right"><a href="/community/request.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image13','','/img/common/quick_3_ov.gif',1)"><img src="/img/common/quick_3.gif" name="Image13" border="0"></a></td>
	  </tr>
	  <tr>
		<td align="center"><img src="/img/common/quick_bottom.gif" border="0" /></td>
	  </tr>
	</table>
	<table width="53" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td height="3"></td>
	  </tr>
	  <tr>
		<td align="center"><a href="#"><img src="/img/common/top.gif" border="0" /></a></td>
	  </tr>
	</table>
</div>
	<!--2015-07-10 : 박종천-->
	<div id="pop_wrapper" style="width:940px; height:1px; position:relative;z-index:9; "></div>

	<!--2015-06-25 : 박종천-->
	<!--
	<style type="text/css">
		div.banner {position:absolute; top:430px; left:50%; margin-left:490px;}
	</style>
	<div class="banner"><a href="http://qha.co.kr/" target="_blank"><img width="200" height="72" src="/img/qha_link_20150624.gif" alt="큐모발검사"></a></div>
	-->
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="940" height="110" valign="top">
	<script>var ff = f_emb(940, 110, "../flash/menu.swf?pageNum=<?=$pageNum?>&sub=<?=$sub?>","transparent");documentwrite(ff);</script></td></tr>
</table>