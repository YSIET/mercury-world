<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
<title>수은세상</title>
<link href="../css/style.css" rel="stylesheet" type="text/css" />
<script language="javascript" src="../js/f_fscript.js"></script>
<SCRIPT language="javascript" src="../js/etc.js"></SCRIPT>
<!--2016.07.14-->
<meta name="naver-site-verification" content="49469930b8af79467aea1fa71a1e2258732c31ef"/>
<script src="https://code.jquery.com/jquery-1.12.4.js"> </script>
</head>
<body>
<center>
<script>
	$(window).scroll(function(){
		try{
			var elem = $("#quick_menu");
			var pos = $(window).scrollTop();	
			if( pos == 0 ){
				elem.stop().animate({top:100}, 600);
			}else {
				elem.stop().animate({top:pos+100}, 600);
			}
	
		}catch(ex){alert(ex.message);}
	});	
</script>
<style>
	/*이슈 - 따라다니기*/
	#quick_menu {position:absolute; left:50%; margin-left:490px;top:150px; width:53px; z-index:3; background:url(/img/common/quick_top.gif) no-repeat center top ;
		padding-top:57px; 
	}
	#quick_menu ul {margin:0; padding:0; list-style-type:none; background:url(/img/common/quick_bottom.gif) no-repeat center bottom ; padding-bottom:23px; }
	#quick_menu ul li {padding:2px 0; background:url(/img/common/quick_bg.gif) repeat-y; }
	#quick_menu ul li img {padding:0; margin:0; }
	#quick_menu div.top {padding-top:5px; text-align:center; }
	#quick_menu div.top img {cursor:pointer; }
</style>
<div id="quick_menu">
	<ul>
		<li><a href="/site/greeting.php"><img src="/img/common/quick_1.gif" name="Image11"></a></li>
		<li><a href="/community/freeboard.php"><img src="/img/common/quick_2.gif" name="Image12"></a></li>
		<li><a href="/community/request.php"><img src="/img/common/quick_3.gif" name="Image13"></a></li>
	</ul>
	<div class="top"><img src="/img/common/top.gif" alt="top" onclick="window.scrollTo(0, 0);"/></div>
</div>
</div><!--//quick_menu-->

<!--2015-07-10 : 박종천-->
<div id="pop_wrapper" style="width:940px; height:1px; position:relative;z-index:9; "></div>
<!--2020-09-21 : 박종천-->
<style type="text/css">
	.g_clear_both {clear:both; }
	.header {width:940px; margin:0 auto; }
	.header .bt_top {padding:10px 0; text-align:right; }
	.header .bt_top a {font-size:11px; font-family:verdana, arial, 'sans-serif'; }

	.header .logo {float:left;}
	.header .logo img {width:170px; height:41px; }

	/*글로벌 메뉴*/
	.header .gnv {float:right; border-top:solid 1px #00be49; border-bottom:solid 1px #00be49;;}
	.header .gnv a {font-family:sans-serif,  'MalgunGothic','맑은고딕'; letter-spacing:-0.5px; text-decoration:none; }

	.gnv dl {float:left; position:relative; margin:0 0 0 10px; min-width:120px;}
	.gnv dl dt {padding:10px 0;}
	.gnv dl dt a {display:block; font-size:14px;  text-align:center; font-weight:bold; color:#666666; }
	.gnv dl dt a:hover {color:#ff3300;}
	.gnv dl dt.on a {font-weight:bold;  }
	.gnv dl dt.on a {color:#0099cc; }
	.gnv dl dt.on a {color:#0099cc; }
	.gnv dl dt.on a {color:#0099cc; }
	.gnv dl dt.on a {color:#0099cc; }

	.gnv dl dt.on a:hover {}
	.gnv dl dd {width:100%; display:none; position:absolute; left:0px; z-index:8; padding:2px 0; margin:0; border:solid 1px #00be49; border-top:0; }
	.gnv dl dd a {display:block; padding:5px 10px; font-size:15px; text-align:center; margin:0 1px; white-space:nowrap;
		font-size:12px;  background:#ffffff;
	}
	.gnv dl dd a:hover {color:#000000; background:#def7f9;}
	.gnv dl dd a.on {background:#09c2ce; color:#ffffff;  }

	/*좌측메뉴*/
	ul.side_nav {margin:0; padding:5px 0 0 0; list-style-type:none; width:145px; }
	ul.side_nav li  {}
	ul.side_nav li a {display:block; padding:5px 0 5px 22px; border-bottom:solid 1px #dddddd; text-decoration:none; 
		background:url(/img/img_new/left_menu_icon.png) no-repeat 8px 10px;
	}
	ul.side_nav li:last-child a { border-bottom:0; }
	ul.side_nav li a.on, ul.side_nav li a:hover {color:#0099cc; background-position:8px -50px;}
</style>
<div class="header">
	<div class="bt_top">
		<a href="/">HOME</a> |
		<a href="/sitemap/sitemap.php">SITEMAP</a>
	</div>
	<div class="logo"><a href="/"><img src="/img/img_new/logo.gif" alt="로고"/></a></div>

<?
	$menuArr = Array(
		Array("1200","수은이란","/mercury/mercury.php"),
		Array("1200","수은순환과생물농축","/mercury/mercury_cycle.php"),
		Array("1200","어패류속수은","/mercury/fish.php"),
		Array("1200","수은응급처리법","/mercury/emergency.php"),
		Array("1200","수은규제치","/mercury/regulation.php"),

		Array("1300","공지사항","/news/board.php"),
		Array("1300","수은관련뉴스","/news/news.php"),
		Array("1300","수은함유량정보","/news/pds.php"),

		Array("1400","묻고답하기","/community/freeboard.php"),
		Array("1400","분석의뢰","/community/request.php"),
		Array("1400","수은응급처리키트","/community/kit.php"),

		Array("1500","수은섭취량테스트","/content/content.php"),
		Array("1500","ONEDAY수은신호등","/content/one.php")
	);

	//글로벌 네비 출력
	function print_gnv($_group){
		global $menuArr;
		for($i=0; $i<count($menuArr);$i++){
			if($_group != $menuArr[$i][0]){
				continue;
			}
?>
				<a href="<?=$menuArr[$i][2]?>"><?=$menuArr[$i][1]?></a>
<?
		}
	}//
	//좌측 메뉴 출력
	function print_side_nav($_group){
		global $menuArr;
		for($i=0; $i<count($menuArr);$i++){
			if($_group != $menuArr[$i][0]){
				continue;
			}
			$now_class = ($_SERVER['PHP_SELF'] == $menuArr[$i][2]) ? " class=\"on\"":"";
?><li><a href="<?=$menuArr[$i][2]?>"<?=$now_class?>><?=$menuArr[$i][1]?></a></li><?
		}
	}//
?>
	<div class="gnv"  id="gnv">
		<dl>
			<dt><a href="/site/greeting.php">수은세상소개</a></dt>
		</dl>
		<dl>
			<dt><a href="../mercury/mercury.php">수은백서</a></dt>
			<dd>
<?				print_gnv(1200);?>
			</dd>
		</dl>
		<dl>
			<dt><a href="../news/board.php">수은소식</a></dt>
			<dd>
<?				print_gnv(1300);?>
			</dd>
		</dl>
		<dl>
			<dt><a href="../community/freeboard.php">수은상담소</a></dt>
			<dd>
<?				print_gnv(1400);?>
			</dd>
		</dl>
		<dl>
			<dt><a href="../content/content.php">식품속수은</a></dt>
			<dd>
<?				print_gnv(1500);?>
			</dd>
		</dl>
		<div class="g_clear_both"></div>
	</div><!--//gnv-->
	<div class="g_clear_both"></div>
</div>


<script type="text/javascript">
	//글로벌 메뉴 - 서브
	function gnv_subOn(){
		//마우스 오버, 아웃
		$("#gnv dl").on("mouseenter focusin", function(){
			$(this).find("dd").eq(0).stop().slideDown(150);
		}).on("mouseleave focusout", function(){
			$(this).find("dd").eq(0).stop().slideUp(30);
		});
	}
	//글로벌 메뉴 : 현재 메뉴 표시
	function gnvNow(){
		var cid_group = $("#gnv").data("gnv_cgroup") ;
		var cid = $("#gnv").data("gnv_cid") ;
		$("#gnv dl").each(function(){
			if( cid_group == $(this).data("cgroup") ){
				$(this).find("dt").addClass("on");
				$(this).next().addClass("no_vert");
				$(this).addClass("no_vert");
				return;
			}
		});
		$("#gnv dl a").each(function(){
			if( $(this).data("cid") == cid){
				$(this).addClass("on");
				return;
			}
		});
	}

	$(document).ready(function(){
		gnv_subOn() //글로벌 메뉴 서브 : show, hide
		//$.gnvNow(); //글로벌 메뉴 : 현재 메뉴 표시
	});

</script>

