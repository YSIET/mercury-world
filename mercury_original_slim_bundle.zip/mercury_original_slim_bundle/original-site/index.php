<?
$mod_file_path = __FILE__;
include_once "./lib/include.inc2.html";

$pageNum="6";
$sub = "1";
?>
<? include "inc/header.php"; ?>
<style type="text/css">
<!--
#notice03 {
	position:absolute;
	z-index:3;
	visibility: visible;
}
#notice04 {
	position:absolute;
	z-index:2;
	visibility: hidden;
}
#notice10 {
	position:absolute;
	z-index:2;
	visibility: hidden;
}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
//-->
</script>

<script type="text/javascript">
	///메인 배너 - 박종천 2020.11.10
	var bn_interval_id;
	var bn_speed = 1000;
	var bn_pause = 3000;
	var bn_direction = 1;
	var bn_width = 331;
	//메인 배너 : 인터벌
	function banner_interval(){
		bn_interval_id = setInterval(banner_on, bn_pause );
		$('#banner').parent().hover(function(){
			clearInterval(bn_interval_id);
		},function(){
			bn_speed = 1500; 
			bn_interval_id = setInterval(banner_on, bn_pause);
		});
	}
	//메인 배너 : 이동
	function banner_on(){
		bn_width = $('#banner li').width();
		if( bn_direction == -1 ){
			$('#banner').prepend($('#banner li:last')).css("left","-" + bn_width + "px");
			$('#banner').stop().animate({"left":"0"}, bn_speed, "easeOutQuart", function(){;});
		}else{
			$('#banner').stop().animate({"left":"-" + bn_width + "px"}, bn_speed, "easeOutQuart", function(){
				$(this).find("li").first().appendTo($(this));
				$(this).css("left","0px");
			});
		}
	};
	//메인 배너 네비
	function banner_nav(_bn_direction){
		//clearInterval(bn_interval_id);
		bn_direction = _bn_direction;
		//bn_speed = 200; 
		//banner_on();
	}
	banner_interval();//배너
</script>
<style>
	/*배너 박종천 2020.11.10*/
	area {outline:none; }
	div.banner { position:relative; width:331px; background:#ffffff; height:119px;overflow:hidden; padding:0;}
	div.banner ul {position:absolute; padding:0; margin:0; width:3600px; overflow:hidden;}
	div.banner ul li {display:inline-block; width:331px; height:112px; }
	div.banner ul li a img {width:100%; height:100%;}
	div.banner span {display:inline-block; width:30px; height:88px; position:absolute; z-index:3; top:24px; 
		cursor:pointer; background:no-repeat center #ffffff; overflow:hidden; text-indent:-100px; 
	}
	div.banner span:hover {opacity:0.9;}
	div.banner span.nav_left { left:0px; background-image:url(/img/img_new/bn_left.png);}
	div.banner span.nav_right {right:0px; background-image:url(/img/img_new/bn_right.png);}
	div.banner div.main_title1 {display:block; position:absolute; z-index:6; }

	.main_list {padding-left:40px; }
	.main_list a {overflow:hidden; text-overflow:ellipsis;-o-text-overflow:ellipsis; white-space:nowrap; display:block; width:260px; }
</style>

<div id="Layer1">
  <table width="940" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
	  <td width="609"></td>
      <td height="112">
		<div class="banner">
			<div class="main_title1">
				<img src="/img/img_new/main_title1.png" alt="수은백서" usemap="#main_title1"/>
				<map name="main_title1">
					<area shape="rect" coords="287,2,331,27" href="/mercury/mercury.php" alt="더보기"/>
				</map>
			</div>
			<ul id="banner">
				<li><a href="/mercury/mercury.php"><img src="/flash/mercury/1.gif" alt=""></a></li><li><a href="/mercury/mercury_cycle.php"><img src="/flash/mercury/2.gif" alt=""></a></li><li><a href="/mercury/fish.php"><img src="/flash/mercury/3.gif" alt=""></a></li><li><a href="/mercury/emergency.php"><img src="/flash/mercury/4.gif" alt=""></a></li><li><a href="/mercury/regulation.php"><img src="/flash/mercury/5.gif" alt=""></a></li>
			</ul>
			<span class="g_cursor nav_left" onclick="banner_nav(1);" title="왼쪽" />◀</span>
			<span class="g_cursor nav_right" onclick="banner_nav(-1);" title="오른쪽" />▶</span>
		</div><!--//banner-->
	</td>
    </tr>
    <tr>
	  <td></td>
      <td style="padding-top:27">
		<!--게시판 -->
              <div id="notice03">
                  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td>
					  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                          <tr>
						    <td width="3" height="22"></td>
                            <td width="94" rowspan="2"><a href="news/board.php"><img src="img/main/news3_ov.gif" border="0" onMouseOver="this.style.cursor='hand';" /></a></td>
                            <td width="94" rowspan="2"><img src="img/main/news1.gif" onMouseOver="MM_showHideLayers('notice03','','hide','notice04','','show','notice10','','hide')"/></td>
							<td width="94" rowspan="2"><img src="img/main/news2.gif" onMouseOver="MM_showHideLayers('notice03','','hide','notice04','','hide','notice10','','show')"/></td>
                            <td width="46" colspan="2" align="right"><a href="news/board.php"><img src="img/main/more.gif" border="0"></a></td>
                          </tr>
                          <tr>
                            <td height="1" bgcolor="#E3E3E3"></td>
                            <td colspan="2" bgcolor="#E3E3E3"></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td><table cellspacing="0" cellpadding="0" width="100%" border="0">
					  	  <tr>
                            <td width="100%" height="7"></td>
                          </tr>
                          <!--공지사항반복시작 -->
<?
function dateDiff($date1, $date2){
$_date1 = explode("-",$date1);
$_date2 = explode("-",$date2);

$tm1 = mktime(0,0,0,$_date1[1],$_date1[2],$_date1[0]);
$tm2 = mktime(0,0,0,$_date2[1],$_date2[2],$_date2[0]);

return ($tm1 - $tm2) / 86400;
} 

$to_day = date("Y-m-d");


$db->query("SELECT bd_no, bd_title, bd_regDate FROM frame_board_board_notice order by bd_no desc limit 4");
//$data = $db->fetch();

while ($data = $db->fetch()){
	$reg_date = substr($data["bd_regDate"], 0, 10);
	$title = boardGetString($data[bd_title], '1', true, 130);
	$dc =  dateDiff($to_day, $reg_date);
?>
                          <tr>
                            <td height="18" class="main_list"><a href="news/board.php?no=<?=$data["bd_no"]?>&id=board_notice&p=1&or=bd_order&al=asc"><?=$title?> <?if ($dc < 3){?><img src="img/main/new.gif" width="9" height="9" border="0" align="absmiddle" /><?}?></a></td>
                          </tr>
<?
}
?>

                          <!--공지사항반복끝 -->
                      </table> </td>
                    </tr>
                  </table>
            </div>
			<div id="notice04">
                  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td>
					  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
						    <td width="3" height="22"></td>
							<td width="94" rowspan="2"><img src="img/main/news3.gif" onMouseOver="MM_showHideLayers('notice03','','show','notice04','','hide','notice10','','hide')"/></td>
                           <td width="94" rowspan="2"><a href="news/news.php"><img src="img/main/news1_ov.gif" border="0" onMouseOver="this.style.cursor='hand';" /></a></td>
							<td width="94" rowspan="2"><img src="img/main/news2.gif" onMouseOver="MM_showHideLayers('notice03','','hide','notice04','','hide','notice10','','show')"/></td>
                            <td width="46" colspan="2" align="right"><a href="news/news.php"><img src="img/main/more.gif" border="0"></a></td>
                          </tr>
                          <tr>
                            <td height="1" bgcolor="#E3E3E3"></td>
                            <td colspan="2" bgcolor="#E3E3E3"></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td><table cellspacing="0" cellpadding="0" width="100%" border="0">
					  	  <tr>
                            <td height="7" colspan="2"></td>
                          </tr>
                          <!--수은관련뉴스반복시작 -->
<?
$db->query("SELECT bd_no, bd_title, bd_regDate FROM frame_board_board_news2 order by bd_no desc limit 4");
//$data = $db->fetch();

while ($data = $db->fetch()){
	$reg_date = substr($data["bd_regDate"], 0, 10);
	$title = boardGetString($data[bd_title], '1', true, 130);
	$dc =  dateDiff($to_day, $reg_date);
?>
                          <tr>
                            <td height="18" class="main_list"><a href="news/news.php?no=<?=$data["bd_no"]?>&id=board_news2&p=1&or=bd_order&al=asc"><?=$title?> <?if ($dc < 3){?><img src="img/main/new.gif" width="9" height="9" border="0" align="absmiddle" /><?}?></a></td>
                          </tr>
<?
}
?>

                          <!--수은관련뉴스반복끝 -->
                      </table></td>
                    </tr>
                  </table>
               </div>
			   <div id="notice10">
                  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td>
					  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
						    <td width="3" height="22"></td>
                            <td width="94" rowspan="2"><img src="img/main/news3.gif" border="0" onMouseOver="MM_showHideLayers('notice03','','show','notice04','','hide','notice10','','hide')"/></a></td>
							<td width="94" rowspan="2"><a href="news/pds.php"><img src="img/main/news1.gif" border="0" onMouseOver="MM_showHideLayers('notice03','','hide','notice04','','show','notice10','','hide')"/></a></td>
                            <td width="94" rowspan="2"><a href="news/pds.php"><img src="img/main/news2_ov.gif" border="0" onMouseOver="this.style.cursor='hand';" /></td>  
                            <td width="46" colspan="2" align="right"><a href="news/pds.php"><img src="img/main/more.gif" border="0"></a></td>
                          </tr>
                          <tr>
                            <td height="1" bgcolor="#E3E3E3"></td>
                            <td colspan="2" bgcolor="#E3E3E3"></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td><table cellspacing="0" cellpadding="0" width="100%" border="0">
					  	  <tr>
                            <td height="7" colspan="2"></td>
                          </tr>
                          <!--수은함유량반복시작 -->
<?
$db->query("SELECT bd_no, bd_title, bd_regDate FROM frame_board_pds order by bd_no desc limit 4");
//$data = $db->fetch();

while ($data = $db->fetch()){
	$reg_date = substr($data["bd_regDate"], 0, 10);
	$title = boardGetString($data[bd_title], '1', true, 130);
	$dc =  dateDiff($to_day, $reg_date);
?>
                          <tr>
                            <td height="18" class="main_list"><a href="news/pds.php?no=<?=$data["bd_no"]?>&id=pds&p=1&or=bd_order&al=asc"><?=$title?> <?if ($dc < 3){?><img src="img/main/new.gif" width="9" height="9" border="0" align="absmiddle" /><?}?></a></td>
                          </tr>
<?
}
?>

                          <!--수은함유량반복끝 -->
                      </table></td>
                    </tr>
                  </table>
            </div>

		<!-- 게시판 -->
	  </td>
	</tr>
  </table>
</div>

<table width="940" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td height="26">&nbsp;</td>
	</tr>
	<tr>
		<td style="padding-top:20px;">
			<img src="/img/img_new/main_visual.gif" alt="메인 이미지" style="width:970px; height:514px;"  usemap="#Map"/>
			<map name="Map">
			  <area shape="rect" coords="663,268,810,409" href="/community/request.php" alt="분석의뢰"/>
			  <area shape="rect" coords="830,269,940,414" href="/test/q.htm" onclick="test_pop(this); return false;" alt="수은IQ테스트"/>
			</map>	
			<script type="text/javascript">
				function test_pop(a_elem){
					var testPop = window.open(a_elem.href, "testPop", "width=710, height=630, scrollbars=yes, resizable=yes, top=10");
					if(testPop){
						testPop.focus();
					}else{
						alert("팝업이 차단되어 있습니다. 해제 후 사용해 주세요.");
					}
				}
			</script>
		</td>
	</tr>
</table>
<? include "inc/footer.php"; ?>


<?

$db->query("SELECT * FROM frame_popup where pp_use = '1' and now() >= pp_startDate and now() <= pp_endDate");
while ($data = $db->fetch()){
	$pp_no = $data["pp_no"];
	$pp_width = $data["pp_width"];
	$pp_height = $data["pp_height"];
	$pp_top = $data["pp_top"];
	$pp_left = $data["pp_left"];
	$pp_useScrollbars = $data["pp_useScrollbars"];
	$pp_useResize = $data["pp_useResize"]
?>
<form name=popup_<?=$pp_no?> method=post action="pop.php" target="notice<?=$pp_no?>">
<input type=hidden name=no value="<?=$pp_no?>">
</form>
<script language="javascript">
//새창띄우기1 시작

  window.open('pop.php','notice<?=$pp_no?>','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=<?=$pp_useScrollbars?>,resizable=<?=$pp_useResize?>,width=<?=$pp_width?>,height=<?=$pp_height?>,top=<?=$pp_top?>,left=<?=$pp_left?>'); 
  document.popup_<?=$pp_no?>.submit();
 //noticeWindow.opener = self; 

//새창띄우기1 끝

//-->
</script>
<?
}
?>


<?
$db ->close();
?>
