<html>
<head>
<title>수은세상</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<frameset rows="0, 100%" cols="1*" border="0"> 
  <frame name="top" scrolling="no" marginwidth="0" marginheight="0" src="top.php" noresize>
  <frame name="bottom" scrolling="auto" marginwidth="10" marginheight="14" src="main.php">
  <noframes> 
  <body bgcolor="#FFFFFF" text="#000000" link="#0000FF" vlink="#800080" alink="#FF0000">
  <p>이 페이지를 보려면, 프레임을 볼 수 있는 브라우저가 필요합니다.</p>
  </body>
  </noframes> </frameset>
</html><script>check_content()</script>