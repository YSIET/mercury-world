<?
$mod_file_path = __FILE__;
include_once "./lib/include.inc2.html";




$pageNum="5";
$sub = "1";
?>
<? include "inc/header.php"; ?>
<style type="text/css">
<!--
#notice03 {
	position:absolute;
	z-index:3;
	visibility: visible;
}
#notice04 {
	position:absolute;
	z-index:2;
	visibility: hidden;
}
#notice10 {
	position:absolute;
	z-index:2;
	visibility: hidden;
}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
//-->
</script>
<div id="Layer1">
  <table width="940" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
	  <td width="609"></td>
      <td height="112"><script>var ff3 = f_emb(331, 112, "flash/mercury.swf","transparent");documentwrite(ff3);</script></td>
    </tr>
    <tr>
	  <td></td>
      <td style="padding-top:27">
		<!--게시판 -->
              <div id="notice03">
                  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td>
					  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                          <tr>
						    <td width="3" height="22"></td>
                            <td width="94" rowspan="2"><a href="news/board.php"><img src="img/main/news3_ov.gif" border="0" onMouseOver="this.style.cursor='hand';" /></a></td>
                            <td width="94" rowspan="2"><img src="img/main/news1.gif" onMouseOver="MM_showHideLayers('notice03','','hide','notice04','','show','notice10','','hide')"/></td>
							<td width="94" rowspan="2"><img src="img/main/news2.gif" onMouseOver="MM_showHideLayers('notice03','','hide','notice04','','hide','notice10','','show')"/></td>
                            <td width="46" colspan="2" align="right"><a href="news/board.php"><img src="img/main/more.gif" border="0"></a></td>
                          </tr>
                          <tr>
                            <td height="1" bgcolor="#E3E3E3"></td>
                            <td colspan="2" bgcolor="#E3E3E3"></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td><table cellspacing="0" cellpadding="0" width="100%" border="0">
					  	  <tr>
                            <td width="100%" height="7"></td>
                          </tr>
                          <!--공지사항반복시작 -->
<?
function dateDiff($date1, $date2){
$_date1 = explode("-",$date1);
$_date2 = explode("-",$date2);

$tm1 = mktime(0,0,0,$_date1[1],$_date1[2],$_date1[0]);
$tm2 = mktime(0,0,0,$_date2[1],$_date2[2],$_date2[0]);

return ($tm1 - $tm2) / 86400;
} 

$to_day = date("Y-m-d");


$db->query("SELECT bd_no, bd_title, bd_regDate FROM frame_board_board_notice order by bd_no desc limit 4");
//$data = $db->fetch();

while ($data = $db->fetch()){
	$reg_date = substr($data["bd_regDate"], 0, 10);
	$title = boardGetString($data[bd_title], '1', true, 30);
	$dc =  dateDiff($to_day, $reg_date);
?>
                          <tr>
                            <td height="18" style="padding-left:20"><a href="news/board.php?no=<?=$data["bd_no"]?>&id=board_notice&p=1&or=bd_order&al=asc">&nbsp;&nbsp;<?=$title?> <?if ($dc < 3){?><img src="img/main/new.gif" width="9" height="9" border="0" align="absmiddle" /><?}?></a></td>
                          </tr>
<?
}
?>

                          <!--공지사항반복끝 -->
                      </table> </td>
                    </tr>
                  </table>
            </div>
			<div id="notice04">
                  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td>
					  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
						    <td width="3" height="22"></td>
							<td width="94" rowspan="2"><img src="img/main/news3.gif" onMouseOver="MM_showHideLayers('notice03','','show','notice04','','hide','notice10','','hide')"/></td>
                           <td width="94" rowspan="2"><a href="news/news.php"><img src="img/main/news1_ov.gif" border="0" onMouseOver="this.style.cursor='hand';" /></a></td>
							<td width="94" rowspan="2"><img src="img/main/news2.gif" onMouseOver="MM_showHideLayers('notice03','','hide','notice04','','hide','notice10','','show')"/></td>
                            <td width="46" colspan="2" align="right"><a href="news/news.php"><img src="img/main/more.gif" border="0"></a></td>
                          </tr>
                          <tr>
                            <td height="1" bgcolor="#E3E3E3"></td>
                            <td colspan="2" bgcolor="#E3E3E3"></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td><table cellspacing="0" cellpadding="0" width="100%" border="0">
					  	  <tr>
                            <td height="7" colspan="2"></td>
                          </tr>
                          <!--수은관련뉴스반복시작 -->
<?
$db->query("SELECT bd_no, bd_title, bd_regDate FROM frame_board_board_news2 order by bd_no desc limit 4");
//$data = $db->fetch();

while ($data = $db->fetch()){
	$reg_date = substr($data["bd_regDate"], 0, 10);
	$title = boardGetString($data[bd_title], '1', true, 30);
	$dc =  dateDiff($to_day, $reg_date);
?>
                          <tr>
                            <td height="18" style="padding-left:20"><a href="news/news.php?no=<?=$data["bd_no"]?>&id=board_news2&p=1&or=bd_order&al=asc">&nbsp;&nbsp;<?=$title?> <?if ($dc < 3){?><img src="img/main/new.gif" width="9" height="9" border="0" align="absmiddle" /><?}?></a></td>
                          </tr>
<?
}
?>

                          <!--수은관련뉴스반복끝 -->
                      </table></td>
                    </tr>
                  </table>
               </div>
			   <div id="notice10">
                  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td>
					  <table border="0" width="100%" cellspacing="0" cellpadding="0">
                          <tr>
						    <td width="3" height="22"></td>
                            <td width="94" rowspan="2"><img src="img/main/news3.gif" border="0" onMouseOver="MM_showHideLayers('notice03','','show','notice04','','hide','notice10','','hide')"/></a></td>
							<td width="94" rowspan="2"><a href="news/pds.php"><img src="img/main/news1.gif" border="0" onMouseOver="MM_showHideLayers('notice03','','hide','notice04','','show','notice10','','hide')"/></a></td>
                            <td width="94" rowspan="2"><a href="news/pds.php"><img src="img/main/news2_ov.gif" border="0" onMouseOver="this.style.cursor='hand';" /></td>  
                            <td width="46" colspan="2" align="right"><a href="news/pds.php"><img src="img/main/more.gif" border="0"></a></td>
                          </tr>
                          <tr>
                            <td height="1" bgcolor="#E3E3E3"></td>
                            <td colspan="2" bgcolor="#E3E3E3"></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td><table cellspacing="0" cellpadding="0" width="100%" border="0">
					  	  <tr>
                            <td height="7" colspan="2"></td>
                          </tr>
                          <!--수은함유량반복시작 -->
<?
$db->query("SELECT bd_no, bd_title, bd_regDate FROM frame_board_pds order by bd_no desc limit 4");
//$data = $db->fetch();

while ($data = $db->fetch()){
	$reg_date = substr($data["bd_regDate"], 0, 10);
	$title = boardGetString($data[bd_title], '1', true, 30);
	$dc =  dateDiff($to_day, $reg_date);
?>
                          <tr>
                            <td height="18" style="padding-left:20"><a href="news/pds.php?no=<?=$data["bd_no"]?>&id=pds&p=1&or=bd_order&al=asc">&nbsp;&nbsp;<?=$title?> <?if ($dc < 3){?><img src="img/main/new.gif" width="9" height="9" border="0" align="absmiddle" /><?}?></a></td>
                          </tr>
<?
}
?>

                          <!--수은함유량반복끝 -->
                      </table></td>
                    </tr>
                  </table>
            </div>

		<!-- 게시판 -->
	  </td>
	</tr>
  </table>
</div>

<table width="970" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="26">&nbsp;</td>
  </tr>
  <tr>
    <td height="514" background="img/main/bg.gif" style="background-repeat:no-repeat; background-position:center"><script>var ff2 = f_emb(970, 514, "flash/main.swf","transparent");documentwrite(ff2);</script></td>
  </tr>
</table>
<? include "inc/footer.php"; ?>
<?
$db ->close();
?>