<?
$pageNum="2";
$sub = "4";
?>
<? include "../inc/header.php"; ?>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="213" valign="top">
	<!--left -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td><img src="../img/mercury/left_top.gif" /></td>
	  </tr>
	  <tr>
		<td background="../img/mercury/left_bg.gif" style="padding-left:18"><script>var ff4 = f_emb(140, 150, "/flash/left_mercury.swf?pageNum=<?=$sub?>","transparent");documentwrite(ff4);</script></td>
	  </tr>
	  <tr>
		<td><img src="../img/mercury/left_bottom.gif" /></td>
	  </tr>
	</table>
	<!--/left -->	</td>
	<td width="727" align="center" valign="top">
	<!--con -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2"><img src="../img/mercury/img.gif" /></td>
      </tr>
      <tr>
        <td width="20%" valign="bottom"><img src="../img/mercury/title_4.gif" /></td>
        <td width="80%" align="right" valign="bottom" class="here" style="padding-bottom:3">HOME &gt; 수은백서 &gt; 수은응급처리법</td>
      </tr>
      <tr>
        <td height="3" background="../img/mercury/title_line_1.gif"></td>
        <td height="3" background="../img/mercury/title_line_2.gif"></td>
      </tr>
      <tr>
        <td height="27" colspan="2"></td>
        </tr>
    </table>
	<table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="545" height="30" class="c2 bold"><img src="../img/common/icon_b8.gif" align="absmiddle" /> <img src="../img/mercury/st4_01.gif" align="absmiddle" /></td>
        <td width="155" rowspan="3" align="center" class="c2 bold"><img src="../img/mercury/m_6.gif" /></td>
        </tr>
      <tr>
        <td style="padding-left:20"> &nbsp;금속수은을 포함하는 온도계나 다른 장치들이 파손 시 유출된 수은은 방울로 흩어져 청소하기 어려우며, 느린 속도이지만 상온에서 공기 중으로 증발됩니다. 증발되는 수은증기는 무색·무취·무미이고 흡입 시 매우 유독합니다. <br/>
&nbsp;단기간에 고농도의 수은 또는 수은증기에 노출됐을 경우에 매스꺼움, 숨 가쁨, 기관지염, 편두통, 그리고 피로를 유발할 수 있습니다. 또한 장기간동안 노출된 경우에는 신경계, 신장, 그리고 간에 손상을 입을 수 있습니다. 증상으로는 떨림, 손끝발끝 마비, 근육제어손상, 기억력 감퇴, 신장질병이 있습니다. </td>
        </tr>
      
      <tr>
        <td height="27" align="center">&nbsp;</td>
        </tr>
    </table>
	<table width="700" border="0" cellspacing="0" cellpadding="0">
	<tr></tr>
    <tr>
      <td height="30" class="c2 bold" colspan="2"><img src="../img/common/icon_b8.gif" align="absmiddle" /> <img src="../img/mercury/st_0104.gif" align="absmiddle" /></td>
    </tr>
    <tr>
      <td width="3%" align="right" class="c2 bold" style="padding:5 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
      <td width="95%" height="6" colspan="2" style="padding:5 0 5 0" ><span class="c2 bold">수은을 진공청소기로 절대 치우면 안됩니다.</span></td>
    </tr>
    <tr>
      <td align="center" valign="top"></td>
      <td colspan="2" style="padding-left:5">&raquo; 진공청소기는 공기 중의 수은기체가 증가시켜 수은노출의 증가를 가져옵니다. 또한 진공청소기 필터도 오염되기 때문에 폐기해야 합니다. </td>
    </tr>
    <tr>
      <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
      <td height="6" colspan="2" style="padding:10 0 5 0"><span class="c2 bold">빗자루나 붓으로 수은을 쓸면 안됩니다.</span></td>
    </tr>
    <tr>
      <td align="center" valign="top"></td>
      <td colspan="2" style="padding-left:5">&raquo; 수은을 더 작은 방울로 만들고, 사방으로 흩어지게 하여 청소를 더 어렵게 만듭니다.</td>
    </tr>
    <tr>
      <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
      <td height="6" colspan="2" style="padding:10 0 5 0"><span class="c2 bold">가정용 세척제로 수은을 청소하면 안됩니다.</span></td>
    </tr>
    <tr>
      <td align="center" valign="top"></td>
      <td colspan="2" style="padding-left:5">&raquo; 세척제에 함유되어있는 염소 또는 암모니아가 수은과 격렬하게 반응하여 유독가스를 방출할 수 있기 때문입니다.</td>
    </tr>
    <tr>
      <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
      <td height="6" colspan="2" style="padding:10 0 5 0"><span class="c2 bold">수은에 오염된 옷이나 신발은 절대로 세탁기 세척을 금지하시고, 페기처분 합니다.</span></td>
    </tr>
    <tr>
      <td align="center" valign="top"></td>
      <td colspan="2" style="padding-left:5">&raquo; 수은은 세탁기와 하수에도 오염될 수 있기 때문입니다. 폐기처분 시에는 밀폐봉투에 담아 폐기합니다.</td>
    </tr>
    <tr>
      <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
      <td height="6" colspan="2" style="padding:10 0 5 0"><span class="c2 bold">수은을 쓰레기통이나 소각로에 버리면 안됩니다.</span></td>
    </tr>
    <tr>
      <td align="center" valign="top"></td>
      <td colspan="2" style="padding-left:5">&raquo; 수은은 상온에서도 증발하는 성질을 가지고 있기 때문에 2차적 오염을 유발할 수 있고, 특히 수은을 소각하게 되면 매우위험합니다.</td>
    </tr>
    <tr>
      <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
      <td height="6" colspan="2" style="padding:10 0 5 0"><span class="c2 bold">수은을 절대 하수구에 버리거나 유입되지 않도록 합니다.</span></td>
    </tr>
    <tr>
      <td align="center" valign="top"></td>
      <td colspan="2" style="padding-left:5">&raquo; 하수구에서 천천히 수은이 증발하여 계속적으로 수은노출을 유발합니다.</td>
    </tr>
    <tr>
      <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
      <td height="6" colspan="2" style="padding:10 0 5 0"><span class="c2 bold">수은처리 시 사용한 장갑이나 모든 용품은 지퍼백에 담아 분리배출하며, 수은처리 후 손을 깨끗이 닦아줍니다.</span></td>
    </tr>
    <tr>
      <td align="right" valign="top" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif" vspace="2"/ align="abs middle"></td>
      <td height="6" colspan="2" style="padding:10 0 5 0"><span class="c2 bold">모든 처리가 끝난 후에도 수은누출장소를 48시간이상 환기시켜 눈에 보이지 않는 수은증기에 노출되는 것을 방지합니다.</span></td>
    </tr>
    <tr>
      <td height="20" align="center">&nbsp;</td>
    </tr>
    </table>
	<table width="700" border="0" cellspacing="0" cellpadding="0">
	  <tr>
	    <td height="30" colspan="3" class="c2 bold"><img src="../img/common/icon_b8.gif" align="absmiddle" /> <img src="../img/mercury/st_0101.gif" align="absmiddle" /></td>
	    </tr>
	  <tr>
	    <td colspan="3" align="left"class="c2 bold" style="padding:0 0 0 12"><img src="../img/mercury/st_0102.gif" /> </td>
	    </tr>
	  <tr>
        <td width="5%" align="right" class="c2 bold" style="padding:6 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
	    <td colspan="2" height="12" style="padding:6 0 5 0"><span class="bold">딱딱한 표면에 흘렸을 경우</span></td>
	    </tr>
	  <tr>
	    <td colspan="3" align="right" class="c2 bold" style="padding:0 4 5 0"><table width="665" border="0" cellspacing="0" cellpadding="0">
	      <tr>
	        <td width="13" valign="top">①</td>
	        <td width="647" style="padding-left:3">조심스럽게 파손된 유리조각들을 집어 타올에 올려놓고 접어서 밀폐용기에 담아 폐기처분합니다.</td>
	        </tr>
	      <tr>
	        <td valign="top">②</td>
	        <td style="padding-left:3">두꺼운 종이나 카드를 이용하여 빠르고 조심스럽게 수은방울을 모읍니다. 수은이 누출된 곳 바깥쪽에서부터 누출된 곳으로 이동하면서 청소합니다. 모은 수은방울도 새지 않게 밀폐용기에 담아 분리배출 합니다.</td>
	        </tr>
	      <tr>
	        <td valign="top">③</td>
	        <td style="padding-left:3">보이는 수은을 모두 처리했다고 생각이 되면 수은이 누출된 곳에 손전등을 비춰서 반짝이는 것이 있는지 확인합니다. 낮은각도에서 많은 방향에 비춰보면 수은방울과 유리조각이 빛에 반사되어 빛나는 것을 확인 할 수 있습니다.</td>
	        </tr>
	      <tr>
	        <td valign="top">④</td>
	        <td style="padding-left:3">추가적으로 황가루를 수은 누출된 장소에 뿌려 수은방울을 청소할 수 있습니다. 황가루가 노란색에서 갈색으로 변하게 되면 여전히 수은이 존재하는 것이므로 좀 더 청소가 필요하다는 것을 알 수 있습니다. </td>
	        </tr>
	      <tr>
	        <td valign="top">⑤</td>
	        <td style="padding-left:3">수은이 누출된 장소를 적어도 이틀이상 환기를 시켜줍니다. 만약 많은 양의 수은이 누출된 곳의 경우에는 3개월 동안 환기시킨 뒤 청소를 해야 합니다. </td>
	        </tr>
	      </table></td>
	    </tr>
	  <tr>
	    <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
	    <td colspan="2" height="6" style="padding:10 0 5 0"><span class="bold">카펫이나 면 종류의 표면이 흘렸을 경우</span></td>
	    </tr>
	  <tr>
	    <td height="6" colspan="3" align="right" class="c2 bold" style="padding:0 4 5 0"><table width="665" border="0" cellspacing="0" cellpadding="0">
	      <tr>
	        <td width="13" valign="top">①</td>
	        <td width="647" style="padding-left:3">폐기할 수 있는 표면에 수은 방울이 여전히 눈에 보인다면, 수은을 표면 가운데로 조심스럽게 모아서 밀폐봉투에 담습니다. 수은이 보이지 않는다면 수은에 노출된 물건을 실외로 옮겨서 적어도 24시간을 둡니다.<br/>
	          전체를 폐기하기 힘든 경우에는 날카로운 칼을 이용하여 수은에 오염된 부분을 잘라내 폐기해도 됩니다. </td>
	        </tr>
	      <tr>
	        <td valign="top">②</td>
	        <td style="padding-left:3">제거할 수 없는 카펫이나 가구 등에 수은을 흘린 경우에 가능하다면 보이는 수은방울을 두꺼운 종이나 카드로 모아 밀폐용기에 담습니다. </td>
	        </tr>
	      <tr>
	        <td valign="top">③</td>
	        <td style="padding-left:3">눈에 보이지 않는 잔여수은은 손전등을 이용해 확인 후 제거합니다. </td>
	        </tr>
	      <tr>
	        <td valign="top">④</td>
	        <td style="padding-left:3">가구나 카펫 경우에는 눈에 보이지 않아도 수은이 완벽하게 제거되지 않으므로 폐기하는 것을 권고합니다. </td>
	        </tr>
	      </table></td>
	    </tr>
	  <tr>
	    <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
	    <td colspan="2" height="6" style="padding:10 0 5 0"><span class="bold">흡습성이 있는 표면이나 틈새가 있는 곳(나무 바닥)에 흘렸을 경우</span></td>
	    </tr>
	  <tr> 
	    <td colspan="3" align="right" valign="top" style="padding:0 4 5 0"><table width="665" border="0" cellspacing="0" cellpadding="0">
	      <tr>
	        <td width="13" valign="top">①</td>
	        <td width="647" style="padding-left:3">수은은 균열이 난 틈새로 스며들게 됩니다. 이런 경우에는 수은을 완전하게 제거할 수 없습니다. 만약 가능하다면 틈새표면을 에폭시 페인트, 폴리우레탄 또는 다른 밀봉시약으로 바릅니다.</td>
	        </tr>
	      </table></td>
	    </tr>
	  <tr>
	    <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
	    <td colspan="2" height="6" style="padding:10 0 5 0"><span class="bold">싱크대나 하수구에 흘렸을 경우</span></td>
	    </tr>
	  <tr>
	    <td colspan="3" align="right" valign="top" style="padding:0 4 5 0"><table width="665" border="0" cellspacing="0" cellpadding="0">
	      <tr>
	        <td width="13" valign="top">①</td>
	        <td width="647" style="padding-left:3">일단 배관이 J자형인지 S자형인지 확인하여 꺾인 부분의 배관속 수은을 처리해야합니다. 만약 수은이 배관에 존재하면 집안에 증발되어 수은기체가   생기게 되기 때문입니다. <BR>
	          가장 이상적인 처리방법은 꺾인 부분의 배관을 분리해 밀폐용기에 담아 폐기 처분하고, 새 관을 설치하는 것입니다.   만약 배관을 교체하지 않는다면, 파이프 윗부분을 봉인하고 액체수은을 밀폐용기에 회수하면 됩니다. </td>
	        </tr>
	      </table></td>
	    </tr>
	  <tr>
	    <td colspan="3" align="center" valign="top"></td>
	    </tr>
	  <tr>
	    <td align="right" class="c2 bold" style="padding:10 4 5 0"><img src="../img/mercury/ico_0102.gif"/ align="abs middle"></td>
	    <td colspan="2" height="6" style="padding:10 0 5 0"><span class="bold">물속에 흘렸을 경우</span></td>
	    </tr>
	  <tr>
	    <td colspan="3" align="right" valign="top" style="padding:0 4 5 0"><table width="665" border="0" cellspacing="0" cellpadding="0">
	      <tr>
	        <td width="13" valign="top">①</td>
	        <td width="647" style="padding-left:3">가능한 한 수은방울이 흩어지지 않게 주의하며 작은 컵 등을 이용하여 물을 모두 제거합니다. 금속수은은 물에 용해되지 않으므로 제거하는 물은   수은에 오염되지 않은 것입니다. </td>
	        </tr>
	      <tr>
	        <td valign="top">②</td>
	        <td style="padding-left:3">깨지지 않는 용기에 수은방울을 회수합니다</td>
	        </tr>
	      <tr>
	        <td valign="top">③</td>
	        <td style="padding-left:3">눈에 보이는 수은이 모두 회수되었으면, 배수시킵니다.</td>
	        </tr>
	      </table></td>
	    </tr>
	  </table>
	<table width="700" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="30" class="c2 bold" style="padding:20 0 8 12"><img src="../img/mercury/st_0103.gif" align="absmiddle" />   </td>
        <td width="26%" rowspan="5" align="center" class="c2 bold"><img src="../img/mercury/m_5.gif" /></td>
      </tr>
      <tr>
        <td align="right" ><table width="485" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td colspan="2" valign="top" style="padding-bottom:5">액체 상태인 금속수은이 들어있는 온도계와는 다르게, 예를 들어 약 13cm의 형광등은 10~40 mg의 수은이 기체 상태로 존재합니다.</td>
            </tr>
          <tr>
            <td width="13" valign="top">①</td>
            <td width="472" align="left" style="padding-left:3">형광등이 파손 된 장소를 즉시 환기시키고, 유리와 잔해를 파손유리에 보호되는 장갑을 사용해 밀폐용기에 담아 폐기합니다.</td>
          </tr>
          <tr>
            <td height="13" valign="top">②</td>
            <td align="left" style="padding-left:3">그 후 형광등이 파손된 공간을 12~24시간 동안 환기시킵니다.</td>
          </tr>
        </table></td>
        </tr>
		 <tr>
        <td align="right" valign="top"><table width="485" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="13" valign="top">&nbsp;</td>
            <td width="435" style="padding-left:3">&nbsp;</td>
          </tr>
        </table></td>
        </tr>
    </table>
	<!--/con --></td>
  </tr>
</table><table width="100" height="30" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<? include "../inc/footer.php"; ?>