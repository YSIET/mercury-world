<?
$pageNum="3";
$sub = "2";
?>
<? include "../inc/header.php"; ?>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="213" valign="top">
	<!--left -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td><img src="../img/news/left_top.gif" /></td>
	  </tr>
	  <tr>
		<td background="../img/news/left_bg.gif" style="padding-left:18">
		<!--<script>var ff4 = f_emb(140, 150, "/flash/left_news.swf?pageNum=<?=$sub?>","transparent");documentwrite(ff4);</script>-->
		<ul class="side_nav"><?	print_side_nav(1300); //@@@ /inc/header.php에 정의됨.?></ul>
		</td>
	  </tr>
	  <tr>
		<td><img src="../img/news/left_bottom.gif" /></td>
	  </tr>
	</table>
	<!--/left -->	</td>
	<td width="727" valign="top">
	<!--con -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2"><img src="../img/news/img.gif" /></td>
      </tr>
      <tr>
        <td width="17%" valign="bottom"><img src="../img/news/title_1.gif" /></td>
        <td width="83%" align="right" valign="bottom" class="here" style="padding-bottom:3">HOME &gt;<span class="here" style="padding-bottom:3"> 수은소식</span> &gt; 수은관련뉴스 </td>
      </tr>
      <tr>
        <td height="3" background="../img/news/title_line_1.gif"></td>
        <td height="3" background="../img/news/title_line_2.gif"></td>
      </tr>
      <tr>
        <td height="27" colspan="2"></td>
        </tr>
    </table>
	<script>
 function resizeFrame(iframeObj){
  var innerBody = iframeObj.contentWindow.document.body;
  oldEvent = innerBody.onclick;
  innerBody.onclick = function(){ resizeFrame(iframeObj, 1);oldEvent; };
  var innerHeight = innerBody.scrollHeight + (innerBody.offsetHeight - innerBody.clientHeight);
  iframeObj.style.height = innerHeight;
  var innerWidth = innerBody.scrollWidth + (innerBody.offsetWidth - innerBody.clientWidth);
  iframeObj.style.width = innerWidth;     
  if( !arguments[1] )        /* 특정 이벤트로 인한 호출시 스크롤을 그냥 둔다. */
    this.scrollTo(1,1);
 }
</script>
<?

if ($no){
	$url = "/modules/board/bd_view.html?no=$no&id=board_news2&p=1&or=bd_order&al=asc";
}else{
	$url = "/modules/board/bd_list.html?id=board_news2";
}
?>
<iframe src="<?=$url?>" onload="resizeFrame(this)" frameborder=0 width=100% scrolling="no"></iframe>
	<!--/con --></td>
  </tr>
</table><table width="100" height="30" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<? include "../inc/footer.php"; ?>