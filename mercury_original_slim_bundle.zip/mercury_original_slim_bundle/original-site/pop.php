<?
$mod_file_path = __FILE__;
include_once "./lib/include.inc2.html";
?>
<?
$no = trim( $_POST["no"] );
$db->query("SELECT * FROM frame_popup where pp_use = '1' and now() >= pp_startDate and now() <= pp_endDate");
$data = $db->fetch();
$pp_title = $data["pp_title"];
$pp_content = $data["pp_content"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>수은세상</title>
<style type="text/css">
<!--
body,td,th {
	font-size: 12px;
	color: #666666;
}
body {
	background-color: #FFFFFF;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.style1 {color: #FFFFFF}
.style2 {
	font-size: 16px;
	font-weight: bold;
}
-->
</style>

</head>

 <body>
 <script language="javascript">
<!--
  function setCookie( name, value, expiredays ) {
//    var todayDate = new Date();
//    todayDate.setDate( todayDate.getDate() + expiredays );
//    document.cookie = name + "=" + escape( value ) + "; path=/; expires=" + todayDate.toGMTString() + ";"
  }
  function closeWin() {

	window.close();
  }

  window.focus();

//-->
</script>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3" background="img/bg2.gif" style="background-repeat:no-repeat; background-position:left top; padding:80px 30px 30px 30px" bgcolor="#FFFFFF">

	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td height=80></td>
		</tr>
        <tr>
          <td height="30" align=center valign="top"><span class="style2"><?=$pp_title?></span><br />          
        </tr>
        <tr>
          <td height="100"><?=$pp_content?></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td height="20" colspan="3" align="center" bgcolor="#999999">
      <a href="javascript:closeWin();">[닫기]</a></td>
  </tr>
</table>
</body>

</HTML>
<?
$db ->close();
?>