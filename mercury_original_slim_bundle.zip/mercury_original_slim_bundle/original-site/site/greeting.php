<?
$pageNum="1";
$sub = "1";
?>
<? include "../inc/header.php"; ?>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="213" valign="top">
	<!--left -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td><img src="../img/site/left_top.gif" width="213" height="150" /></td>
	  </tr>
	  <tr>
		<td background="../img/site/left_bg.gif" style="padding-left:18"></td>
	  </tr>
	  <tr>
		<td><img src="../img/site/left_bottom.gif" width="213" height="75" /></td>
	  </tr>
	</table>
	<!--/left -->	</td>
	<td width="727" align="center" valign="top">
	<!--con -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2"><img src="../img/site/img.gif" width="727" height="150" /></td>
      </tr>
      <tr>
        <td width="17%" valign="bottom"><img src="../img/site/title_1.gif" /></td>
        <td width="83%" align="right" valign="bottom" class="here" style="padding-bottom:3">HOME &gt; 수은세상소개 </td>
      </tr>
      <tr>
        <td height="3" background="../img/site/title_line_1.gif"></td>
        <td height="3" background="../img/site/title_line_2.gif"></td>
      </tr>
      <tr>
        <td height="27" colspan="2"></td>
        </tr>
    </table>
	<table width="95%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="7" valign="top"><img src="../img/site/greeting_3.gif" /></td>
      </tr>
    </table>
	<br />
	<!--/con --></td>
  </tr>
</table><table width="100" height="30" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<? include "../inc/footer.php"; ?>