<?
$pageNum="6";
$sub = "1";
?>
<? include "../inc/header.php"; ?>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="213" valign="top">
	<!--left -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tr>
		<td><img src="../img/sitemap/left_top.gif" /></td>
	  </tr>
	  <tr>
		<td background="../img/sitemap/left_bg.gif">&nbsp;</td>
	  </tr>
	  <tr>
		<td><img src="../img/sitemap/left_bottom.gif" /></td>
	  </tr>
	</table>
	<!--/left -->	</td>
	<td width="727" align="center" valign="top">
	<!--con -->
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td colspan="2"><img src="../img/sitemap/img.gif" width="727" height="150" /></td>
      </tr>
      <tr>
        <td width="11%" valign="bottom"><img src="../img/sitemap/title_1.gif" /></td>
        <td width="89%" align="right" valign="bottom" class="here" style="padding-bottom:3">HOME &gt; 사이트맵</td>
      </tr>
      <tr>
        <td height="3" background="../img/sitemap/title_line_1.gif"></td>
        <td height="3" background="../img/sitemap/title_line_2.gif"></td>
      </tr>
      <tr>
        <td height="27" colspan="2"></td>
        </tr>
    </table>
	<table width="700" border="0" cellspacing="20" cellpadding="0">
      <tr>
        <td width="33%" valign="top">
		<table width="25%" border="0" cellspacing="0" cellpadding="3">
            <tr>
              <td colspan="2" width="100%" height="40" align="center"><a href="../site/greeting.php"><img src="../img/sitemap/sitemap_01.gif" width="147" height="39" border="0" /></a></td>
            </tr>
            <tr>
              <td height="5" colspan="2"></td>
            </tr>
			 <tr>
              <td width="18%" align="right"><img src="../img/common/icon02.gif" /></td>
              <td width="82%"><a href="../site/greeting.php">수은세상소개</a></td>
            </tr>
          </table>
            <br /></td>
        <td width="33%" valign="top"><table width="4%" border="0" cellspacing="0" cellpadding="3">
            <tr>
              <td height="40" colspan="2" align="center"><a href="../mercury/mercury.php"><img src="../img/sitemap/sitemap_02.gif" width="147" height="39" border="0" /></a></td>
            </tr>
            <tr>
              <td height="5" colspan="2"></td>
            </tr>
            <tr>
              <td width="18%" align="right"><img src="../img/common/icon02.gif" /></td>
              <td width="82%"><a href="../mercury/mercury.php">수은이란</a></td>
            </tr>
            <tr align="right">
              <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
            </tr>
            <tr>
              <td align="right"><img src="../img/common/icon02.gif" /></td>
              <td><a href="../mercury/mercury_cycle.php">수은순환과생물농축</a></td>
            </tr>
			<tr align="right">
              <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
            </tr>
			<tr>
              <td width="17%" align="right"><img src="../img/common/icon02.gif" /></td>
              <td width="83%"><a href="../mercury/fish.php">어패류속수은</a></td>
            </tr>
            <tr align="right">
              <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
            </tr>
            <tr>
              <td align="right"><img src="../img/common/icon02.gif" /></td>
              <td><a href="../mercury/emergency.php">수은응급처리법</a></td>
            </tr>
			<tr align="right">
              <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
            </tr>
			<tr>
              <td width="17%" align="right"><img src="../img/common/icon02.gif" /></td>
              <td width="83%"><a href="../mercury/regulation.php">수은규제치</a></td>
            </tr>
        </table></td>
        <td width="34%" valign="top"><table width="4%" border="0" cellspacing="0" cellpadding="3">
            <tr>
              <td height="40" colspan="2" align="center"><a href="../news/news.php"><img src="../img/sitemap/sitemap_03.gif" width="147" height="39" border="0" /></a></td>
            </tr>
            <tr>
              <td height="5" colspan="2"></td>
            </tr>
			<tr>
              <td width="18%" align="right"><img src="../img/common/icon02.gif" /></td>
              <td width="82%"><a href="../news/board.php">공지사항</a></td>
            </tr>
            <tr align="right">
              <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
            </tr>
            <tr>
              <td width="18%" align="right"><img src="../img/common/icon02.gif" /></td>
              <td width="82%"><a href="../news/news.php">수은관련뉴스</a></td>
            </tr>
            <tr align="right">
              <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
            </tr>
			<!-- <tr>
              <td width="18%" align="right"><img src="../img/common/icon02.gif" /></td>
              <td width="82%"><a href="../news/direction.php">수은연구동향</a></td>
            </tr>
            <tr align="right">
              <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
            </tr> -->
			<tr>
              <td width="18%" align="right"><img src="../img/common/icon02.gif" /></td>
              <td width="82%"><a href="../news/pds.php">수은함유량정보</a></td>
            </tr>
        </table></td>
        <td width="34%" valign="top"><table width="4%" border="0" cellspacing="0" cellpadding="3">
          <tr>
            <td height="40" colspan="2" align="center"><a href="../community/freeboard.php"><img src="../img/sitemap/sitemap_04.gif" width="147" height="39" border="0" /></a></td>
          </tr>
          <tr>
            <td height="5" colspan="2"></td>
          </tr>
          <tr>
            <td width="18%" align="right"><img src="../img/common/icon02.gif" /></td>
            <td width="82%"><a href="../community/freeboard.php">묻고답하기</a></td>
          </tr>
          <tr align="right">
            <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
          </tr>
          <tr>
            <td align="right"><img src="../img/common/icon02.gif" /></td>
            <td><a href="../community/request.php">분석의뢰</a></td>
          </tr>
		  <tr align="right">
            <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
          </tr>
		  <tr>
            <td align="right"><img src="../img/common/icon02.gif" /></td>
            <td><a href="../community/kit.php">수은응급처리키트</a></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td valign="top"><table width="4%" border="0" cellspacing="0" cellpadding="3">
          <tr>
            <td height="40" colspan="2" align="center"><a href="../content/content.php"><img src="../img/sitemap/sitemap_06.gif" border="0" /></a></td>
          </tr>
          <tr>
            <td height="5" colspan="2"></td>
          </tr>
          <tr>
            <td width="18%" align="right"><img src="../img/common/icon02.gif" /></td>
            <td width="82%"><a href="../content/content.php">수은섭취량테스트</a></td>
          </tr>
          <tr align="right">
            <td height="1" colspan="2" background="../img/common/dot_01.gif"></td>
          </tr>
		  <tr>
            <td width="18%" align="right"><img src="../img/common/icon02.gif" /></td>
            <td width="82%"><a href="../content/one.php">ONEDAY수은신호등</a></td>
          </tr>
        </table></td>
        <td valign="top">&nbsp;</td>
        <td valign="top">&nbsp;</td>
        <td valign="top">&nbsp;</td>
      </tr>
    </table>
	<!--/con --></td>
  </tr>
</table><table width="100" height="30" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<? include "../inc/footer.php"; ?>